import sys
sys.path.insert(0,"/tmp/ansible_file_payload_cpNv7W/ansible_file_payload.zip")
